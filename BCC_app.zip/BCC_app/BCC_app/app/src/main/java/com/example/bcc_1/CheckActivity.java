package com.example.bcc_1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class CheckActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);

        TextView textView1 = (TextView) findViewById(R.id.check_user_name) ;
        textView1.setText("반천천 교수님") ;

    }

    public void mClick_c (View v) {
        Intent intent_back_check = new Intent(this, MenuActivity.class);
        startActivity(intent_back_check);
    }
}
