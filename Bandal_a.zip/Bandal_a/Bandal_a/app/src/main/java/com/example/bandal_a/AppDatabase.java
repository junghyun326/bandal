package com.example.bandal_a;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Check.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract CheckDao checkDao();
}
