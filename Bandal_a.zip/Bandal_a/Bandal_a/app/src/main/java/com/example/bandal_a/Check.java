package com.example.bandal_a;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Check {
    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "contents")
    private String contents;

    public Check(String contents) {
        this.contents = contents;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    @Override
    public String toString() {
        return "Check{" +
                "id=" + id +
                ", contents='" + contents + '\'' +
                '}';
    }
}
