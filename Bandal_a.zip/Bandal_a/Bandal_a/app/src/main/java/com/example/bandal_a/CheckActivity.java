package com.example.bandal_a;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ToggleButton;

public class CheckActivity extends Activity {
    View m_check_page1, m_check_page2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);

        m_check_page1 = findViewById(R.id.check_page1);
        m_check_page2 = findViewById(R.id.check_page2);
        findViewById(R.id.check_btn_page1).setOnClickListener(mClick);
        findViewById(R.id.check_btn_page2).setOnClickListener(mClick);

    }

    View.OnClickListener mClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            m_check_page1.setVisibility(View.INVISIBLE);
            m_check_page2.setVisibility(View.INVISIBLE);

            switch (v.getId()){
                case R.id.check_btn_page1:
                    m_check_page1.setVisibility(View.VISIBLE);
                    break;
                case R.id.check_btn_page2:
                    m_check_page2.setVisibility(View.VISIBLE);
                    break;
            }
        }
    };

    public void mClick (View v){
        Intent intent = new Intent(this, MenuActivity.class );
        startActivity(intent);
    }
}