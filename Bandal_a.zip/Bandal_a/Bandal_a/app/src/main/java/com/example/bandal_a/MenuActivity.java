package com.example.bandal_a;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ToggleButton;


public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

    }

    public void mClick (View v){
        switch (v.getId()){
            case R.id.back_menu:
                Intent intent = new Intent(this, MainActivity.class );
                startActivity(intent);
                break;
            case R.id.check_1:
                Intent intent1 = new Intent(this, CheckActivity.class );
                startActivity(intent1);
                break;
            case R.id.check_2:
                Intent intent2 = new Intent(this, CheckActivity.class );
                startActivity(intent2);
                break;
            case R.id.list_1:
                Intent intent3 = new Intent(this, ListActivity.class );
                startActivity(intent3);
                break;
            case R.id.list_2:
                Intent intent4 = new Intent(this, ListActivity.class );
                startActivity(intent4);
                break;
        }
    }



}